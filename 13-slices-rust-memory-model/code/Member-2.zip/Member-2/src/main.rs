mod slice_is_fat_pointer;
mod string_and_str;
mod mutable_slices;
mod slice_methods;

use std::io::{self, Write};
use crate::slice_is_fat_pointer::slice_is_fat_pointer;
use crate::string_and_str::string_and_str;
use crate::mutable_slices::mutable_slices;
use crate::slice_methods::slice_methods;

fn main() {
    println!("1) slice is fat pointer\n2) string_and_str\n3) mutable_slices\n4) slice_methods");
    println!("choose demo:");
    print!("> ");
    io::stdout().flush().unwrap();

    let mut input = String::new();
    io::stdin().read_line(&mut input).unwrap();

    match input.trim() {
        "1" => slice_is_fat_pointer::slice_is_fat_pointer(),
        "2" => string_and_str::string_and_str(),
        "3" => mutable_slices::mutable_slices(),
        "4" => slice_methods::slice_methods(),
        _ => print!(""),
        }
}
 
