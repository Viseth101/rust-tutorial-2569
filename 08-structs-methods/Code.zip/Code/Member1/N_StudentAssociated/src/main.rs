struct Student {
    name: String,
    age: i32,
}

impl Student {
    fn introduce(&self) {
        println!("Hi, I'm {}. I'm {} years old.", self.name, self.age);
    }
}

fn main() {
    let student = Student {
        name: String::from("John"),
        age: 20,
    };

    student.introduce();
}