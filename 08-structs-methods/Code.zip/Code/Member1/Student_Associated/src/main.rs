struct Student {
    name: String,
    age: i32,
}

impl Student {
    // Associated Function
    fn new(name: String) -> Student {
        Student {
            name,
            age: 18,
        }
    }

    fn introduce(&self) {
        println!("Hi, I'm {}. I'm {} years old.", self.name, self.age);
    }
}

fn main() {
    let student = Student::new(String::from("John"));

    student.introduce();
}