struct Book {
    title: String,
    author: String,
    pages: u32,
    is_available: bool,
}

fn main() {
    let my_book = Book {
        title: String::from("The Rust Programming Language"),
        author: String::from("Steve Klabnik"),
        pages: 552,
        is_available: true,
    };

    println!("Book: {} by {}", my_book.title, my_book.author);
    println!("Pages: {}, Available: {}", my_book.pages, my_book.is_available);
}
