struct User {
    username: String,
    active: bool,
    sign_in_count: u64,
}

fn build_user(username: String) -> User {
    User {
        username: username,
        active: true,
        sign_in_count: 1,
    }
}

fn main() {
    let mut user1 = build_user(String::from("rust_coder"));
    user1.active = false;

    let user2 = User {
        username: String::from("new_user"),
        ..user1
    };

    println!("User2 active state: {}", user2.active);
}
