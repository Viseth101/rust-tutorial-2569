struct Circle {
    radius: f64,
}

impl Circle {
    fn new(r: f64) -> Circle {
        Circle { radius: r }
    }
}

fn main() {
    let my_circle = Circle::new(5.5);

    println!("Created a circle with radius: {}", my_circle.radius);
}
