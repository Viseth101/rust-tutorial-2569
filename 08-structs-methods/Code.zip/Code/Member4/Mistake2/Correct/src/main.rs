struct Student {
    name: String,
    age: i32,
}
impl Student {
    fn birthday(&mut self) {
        self.age += 1;
    }
}
fn main() {
    let mut student = Student { //<-- มี mut อนุญาตให้ student ถูกแก้ไข
        name: "John".to_string(),
        age: 20,
    };
student.birthday(); }