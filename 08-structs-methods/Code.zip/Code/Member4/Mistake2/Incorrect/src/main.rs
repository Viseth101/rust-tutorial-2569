struct Student {
    name: String,
    age: i32,
}
impl Student {
    fn birthday(&mut self) {
        self.age += 1;
    }
}
fn main() {
    let student = Student { // <-- ไม่มี mut บอกว่า Method นี้ต้องการแก้ไขข้อมูลของ student
        name: "John".to_string(),
        age: 20,
    };
student.birthday(); }