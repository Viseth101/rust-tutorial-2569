/*เก็บข้อมูลนักเรียน`[ให้สร้าง struct Student สำหรับเก็บข้อมูลนักเรียน โดยมีข้อมูลดังนี้`

`- ชื่อ (name) เป็น String`
`- อายุ (age) เป็น i32`

`จากนั้นสร้าง Method ชื่อ show_info() เพื่อแสดงข้อมูลของนักเรียน`

`ผลลัพธ์ที่ต้องการ:`
    `ชื่อ: John`
    `อายุ: 20]`

คำใบ้คือ
`[- ใช้ struct Student`
`- สร้าง Method ภายใน impl Student`
`- Method show_info() ให้ใช้ &self`
`- ใน main() ให้สร้าง Student 1 คน แล้วเรียกใช้ show_info()]`
*/
struct Student {
    name: String,
    age: i32,
}
impl Student {
    fn show_info(&self) {
        println!("ชื่อ: {}", self.name);
        println!("อายุ: {}", self.age);
    }
}
fn main() {
    let student = Student {
        name: "John".to_string(),
        age: 20,
    };
    student.show_info();
}