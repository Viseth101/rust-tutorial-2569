/*ข้อมูลหนังสือ
`[ให้สร้าง struct Book สำหรับเก็บข้อมูลหนังสือ โดยมีข้อมูลดังนี้`

`title เป็น String`
`author เป็น String`
`price เป็น f64`

`จากนั้นสร้าง Method ชื่อ show_info() เพื่อแสดงข้อมูลหนังสือ`

`ผลลัพธ์ที่ต้องการ:`

`ชื่อหนังสือ: Rust Programming`
`ผู้เขียน: John`
`ราคา: 599]

คำใบ้
`[- ใช้ struct Book`
`- สร้าง Method ภายใน impl Book`
`- Method show_info() ให้ใช้ &self`
`- ใช้ println!() เพื่อแสดงข้อมูล`
`- ใน main() ให้สร้างหนังสือ 1 เล่ม แล้วเรียก show_info()]`
*/

struct Book {
    title: String,
    author: String,
    price: f64,
    }
impl Book {
    fn show_info(&self) {
        println!("ชื่อหนังสือ: {}", self.title);
        println!("ผู้เขียน: {}", self.author);
        println!("ราคา: {}", self.price);
        }
}
fn main() {
    let book = Book {
        title: "Rust Programming".to_string(),
        author: "John".to_string(),
        price: 599.0,
        };
    book.show_info();
}