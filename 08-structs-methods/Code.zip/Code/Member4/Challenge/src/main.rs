struct Product {
    name: String,
    price: f64,
    stock: i32,
}

impl Product {
    // แสดงข้อมูลสินค้า
    fn show_info(&self) {
        println!("สินค้า: {}", self.name);
        println!("ราคา: {} บาท", self.price);
        println!("Stock: {}", self.stock);
    }

    // เพิ่มจำนวนสินค้า
    fn add_stock(&mut self, amount: i32) {
        self.stock += amount;
    }

    // ซื้อสินค้า
    fn buy(&mut self, amount: i32) {
        if amount <= self.stock {
            self.stock -= amount;
            println!("ซื้อสำเร็จ!");
        } else {
            println!("ไม่สามารถซื้อได้! สินค้าไม่เพียงพอ");
        }
    }
}

fn main() {
    let mut product = Product {
        name: "Keyboard".to_string(),
        price: 1200.0,
        stock: 10,
    };

    product.show_info();

    println!("\nซื้อสินค้า 3 ชิ้น");
    product.buy(3);
    println!("Stock เหลือ: {}", product.stock);

    println!("\nซื้อสินค้า 10 ชิ้น");
    product.buy(10);
}