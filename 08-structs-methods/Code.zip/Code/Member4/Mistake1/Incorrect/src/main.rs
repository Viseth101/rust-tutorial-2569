struct Student {
    name: String,
    age: i32,
}
    impl Student {
        fn show_info() {
            println!("ชื่อ: {}", self.name);
            println!("อายุ: {}", self.age);
        }
    }
fn main() {
    // สร้าง instance ของ Student
    let student = Student {
        name: String::from("สมชาย ใจดี"),
        age: 20,
    };
    student.show_info();
}