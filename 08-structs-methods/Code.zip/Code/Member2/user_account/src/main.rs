#[derive(Debug)]
struct UserAccount {
    username: String,
    balance: f64,
}

impl UserAccount {
    fn new(username: &str, initial_balance: f64) -> Self {
        Self {
            username: username.to_string(),
            balance: initial_balance,
        }
    }

    fn get_balance(&self) -> f64 {
        self.balance
    }

    fn deposit(&mut self, amount: f64) {
        if amount > 0.0 {
            self.balance += amount;
            println!("ฝากเงินสำเร็จ: +${:.2} | ยอดคงเหลือปัจจุบัน: ${:.2}", amount, self.balance);
        } else {
            println!("จำนวนเงินฝากต้องมากกว่า 0");
        }
    }

    fn withdraw(&mut self, amount: f64) -> Result<f64, String> {
        if amount <= 0.0 {
            Err("จำนวนเงินถอนต้องมากกว่า 0".to_string())
        } else if amount > self.balance {
            Err("ยอดเงินคงเหลือไม่เพียงพอ".to_string())
        } else {
            self.balance -= amount;
            Ok(self.balance)
        }
    }

    fn close_account(self) -> f64 {
        println!("ปิดบัญชีของ {} สำเร็จ คืนเงินคงเหลือ: ${:.2}", self.username, self.balance);
        self.balance
    }
}

fn main() {
    let mut my_account = UserAccount::new("Alice", 100.0);
    println!("เริ่มต้นบัญชี: {:?}", my_account);

    println!("ยอดเงินเริ่มต้น: ${:.2}", my_account.get_balance());

    my_account.deposit(50.0);

    match my_account.withdraw(30.0) {
        Ok(new_balance) => println!("ถอนเงินสำเร็จ ยอดคงเหลือ: ${:.2}", new_balance),
        Err(e) => println!("เกิดข้อผิดพลาด: {}", e),
    }

    let refunded = my_account.close_account();
    println!("เงินคืนเข้ามือ: ${:.2}", refunded);
}