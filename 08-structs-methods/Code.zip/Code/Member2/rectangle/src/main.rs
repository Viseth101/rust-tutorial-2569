#[derive(Debug)]
struct Rectangle {
    width: u32,
    height: u32,
}

impl Rectangle {
    fn new(width: u32, height: u32) -> Self {
        Self { width, height }
    }

    fn area(&self) -> u32 {
        self.width * self.height
    }

    fn scale(&mut self, factor: u32) {
        self.width *= factor;
        self.height *= factor;
    }

    fn square_up(self) -> Self {
        let max_side = if self.width > self.height {
            self.width
        } else {
            self.height
        };
        Self {
            width: max_side,
            height: max_side,
        }
    }
}

fn main() {
    let mut rect = Rectangle::new(10, 5);
    println!("เริ่มต้นรูปทรง: {:?}", rect);

    println!("พื้นที่รูปทรง: {} ตารางหน่วย", rect.area());

    rect.scale(2);
    println!("หลังขยายสเกล 2 เท่า: {:?}", rect);
    println!("พื้นที่ใหม่: {} ตารางหน่วย", rect.area());

    let square = rect.square_up();
    println!("ปรับรูปทรงเป็นจัตุรัส: {:?}", square);
    println!("พื้นที่จัตุรัส: {} ตารางหน่วย", square.area());
}